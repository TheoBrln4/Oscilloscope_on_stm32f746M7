/*
 * LED.h
 *
 *  Created on: Oct 15, 2021
 *      Author: theob
 */

#ifndef INC_LED_H_
#define INC_LED_H_
#include "main.h"

void LED_DispGreen(int);
void LED_SetFreqGreen(int);

#endif /* INC_LED_H_ */
