/*
 * GENE.h
 *
 *  Created on: Nov 19, 2021
 *      Author: theob
 */

#ifndef SRC_GENE_H_
#define SRC_GENE_H_
void GENE_ToggleSetFreqPin(int);
void GENE_TogglePin(void);

#endif /* SRC_GENE_H_ */
